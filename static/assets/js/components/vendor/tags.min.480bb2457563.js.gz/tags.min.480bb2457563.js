//
// Tags input
//
"use strict";var Tags=function(){var a=$('[data-toggle="tags"]');a.length&&a.each(function(){$(this).tagsinput({tagClass:"badge badge-primary"})})}();