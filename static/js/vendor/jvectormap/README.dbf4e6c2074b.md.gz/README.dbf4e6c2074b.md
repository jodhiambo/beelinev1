If you need to get more maps, check out the official Jvectormap website and get the one you need: [Get Maps](http://jvectormap.com/maps/world/africa/)
